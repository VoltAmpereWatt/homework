# echo_via_circular_buffer.py
# Reads a specified wave file (mono) and plays it with an echo.
# This implementation uses a circular buffer.

import pyaudio
import wave
import struct
from myfunctions import clip16

dir = 'C:/Users/rrr39/Google Drive/Academics/DSP Lab 18/assignments/3/'
wavfile = 'author.wav'
print('Play the wave file %s.' % wavfile)

# Open the wave file
wf = wave.open(wavfile, 'rb')

# Read the wave file properties
SIGNAL_LEN  = wf.getnframes()   # Signal length
CHANNELS = wf.getnchannels()    # Number of channels
WIDTH = wf.getsampwidth()       # Number of bytes per sample
RATE = wf.getframerate()        # Sampling rate (frames/second)

wf2 = wave.open(dir+'authorEcho.wav','wb')
wf2.setnchannels(CHANNELS)
wf2.setsampwidth(WIDTH)
wf2.setframerate(RATE)			# samples per second

print('The file has %d channel(s).' % CHANNELS)
print('The frame rate is %d frames/second.' % RATE)
print('The file has %d frames.' % SIGNAL_LEN)
print('There are %d bytes per sample.' % WIDTH)

# Set parameters of delay system
Gdp = 1.0           # direct-path gain
Gff = 0.8           # feed-forward gain
delay_sec = 0.005    # 50 milliseconds
# delay_sec = 0.02
delay_samples = int( RATE * delay_sec )

print('The delay of {0:.3f} seconds is {1:d} samples.'.format(delay_sec, delay_samples))

# Create a buffer to store past values. Initialize to zero.
BUFFER_LEN = delay_samples   # set the length of buffer
buffer = [ 0 for i in range(BUFFER_LEN) ]    

# Open an output audio stream
p = pyaudio.PyAudio()
stream = p.open(format      = pyaudio.paInt16,
                channels    = 1,
                rate        = RATE,
                input       = False,
                output      = True )


# Get first frame (sample)
input_string = wf.readframes(1)

k = 0       # buffer index (circular index)

print("* Start *")

while len(input_string) > 0:

    # Convert string to number
    input_value = struct.unpack('h', input_string)[0]

    # Compute output value
    output_value = Gdp * input_value + Gff * buffer[k]

    # Update buffer
    buffer[k] = input_value

    # Increment buffer index
    k = k + 1
    if k >= BUFFER_LEN:
        # The index has reached the end of the buffer. Circle the index back to the front.
        print(buffer)
        k = 0

    # Convert output value to binary string
    output_string = struct.pack('h', int(clip16(output_value)))

    # Write output value to audio stream
    stream.write(output_string)
    wf2.writeframes(output_string)
    # Get next frame (sample)
    input_string = wf.readframes(1)     

print("* Finished *")

stream.stop_stream()
stream.close()
p.terminate()
