clc; clear all; close all;

[sig,Fs]=audioread('authorEcho.wav','native');
b0 = 1; b1 = 0.8;
b = [b0 b1];
a = 1;

h = filter(b,a,[1,zeros(1,99)]); 
figure;
impz(b,a);
xlim([0,100])
ylim([0,1.5])
grid on

figure;
zplane(b,a);
title('Pole-Zero plot');
grid on;