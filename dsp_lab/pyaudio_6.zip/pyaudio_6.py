# filter_16.py
# 
# Implement the second-order recursive difference equation
# y(n) = x(n) - a1 y(n-1) - a2 y(n-2)
# 
# 16 bit/sample

from math import cos,sin, pi 
import pyaudio
import struct
import wave

# Fs : Sampling frequency (samples/second)
Fs = 8000
f1 = 200
f2 = 1000

T = 1       # T : Duration of audio to play (seconds)
N = T*Fs    # N : Number of samples to play

omega = 2*pi*f1/Fs
r = 1
#left channel coefficients
b0 = 1 
b1 = -2*r*cos(0.5*omega)
b2 = (r)**2

#changing filter coefficients
omega = 2*pi*f2/Fs
#right channel coefficients
a0 = 1
a1 = -2*r*cos(omega)
a2 = r**2

# Initialization
y1 = 0 
y2 = 0
z1 = 0 
z2 = 0

gain = 10000.0
# Also try other values of 'gain'. What is the effect?
# gain = 1000.0

# Create an audio object and open an audio stream for output
p = pyaudio.PyAudio()
#stream holds the properties of the pyaudio object.
stream = p.open(format = pyaudio.paInt16, #16 bits per sample
                channels = 2, #single channel output
                rate = Fs, #number of frames per second
                input = False, #false because not using or reeading from input device
                output = True)

# paInt16 is 16 bits/sample
wf = wave.open('pyaudio_q6.wav','w')
wf.setnchannels(2)			# one channel (mono)
wf.setsampwidth(2)			# two bytes per sample (16 bits per sample)
wf.setframerate(Fs)			# samples per second

# Run difference equation
for n in range(0, N):

    # Use impulse as input signal
    #delta function created. 
    if n == 0:
        x0 = 1.0
        z0 = 2.0
    else:
        x0 = 0.0
        z0 = 0

    # Difference equation
    y = x0 - a1 * y1 - a2 * y2
    z = z0 - b2 * z1 - b1 * z2
    # Delays
    #updating the values of the previous two elements
    #essentially order of filter
    y2 = y1
    y1 = y 
    z2 = z1
    z1 = z0
    # Output
    #multiplying by gain to get input in 2^16 range
    output_value = gain * y
    
    if output_value >= 2**15-1:
        output_value = 2**15-1
    elif output_value <= -2**15:
        output_value = -2**15
    
    output_string = struct.pack('h', int(output_value))   # 'h' for 16 bits
    
    output_value = gain*0.1 * z
    
    if output_value >= 2**15-1:
        output_value = 2**15-1
    elif output_value <= -2**15:
        output_value = -2**15

    output_string += struct.pack('h',int(output_value))
    
    stream.write(output_string)
    wf.writeframes(output_string)

print("* Finished *")
wf.close()
stream.stop_stream()
stream.close()
p.terminate()

#There is a difference in the amplitude that is perceived. This is evident when on putting on headphones, there is one side that is louder than the other side. When the headphones are reversed, this effect is also reversed. However, the signals aren't sufficiently distinct to differentiate between them directly. Hence, the signal is read in MATLAB and it is verified that the signal is a two-channel signal with distinct waveforms for both channels which can be observed in the plots.