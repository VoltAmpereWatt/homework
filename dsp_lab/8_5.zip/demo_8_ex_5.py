# echo_via_circular_buffer.py
# Reads a specified wave file (mono) and plays it with an echo.
# This implementation uses a circular buffer.

import pyaudio
import wave
import struct
from myfunctions import clip16

dir = 'C:/Users/Rahul/Google Drive/Academics/DSP Lab 18/assignments/3/'
wavfile = 'micEcho.wav'
print('Play the wave file %s.' % wavfile)

# Open the wave file
wf = wave.open(wavfile, 'wb')

# Read the wave file properties
#SIGNAL_LEN  = wf.getnframes()   # Signal length
CHANNELS = 1    # Number of channels
WIDTH = 2       # Number of bytes per sample
RATE = 16000        # Sampling rate (frames/second)
TIME = 5
DURATION = TIME * RATE
wf.setnchannels(CHANNELS)
wf.setsampwidth(WIDTH)
wf.setframerate(RATE)			# samples per second

print('The file has %d channel(s).' % CHANNELS)
print('The frame rate is %d frames/second.' % RATE)
print('The file has %d frames.' % DURATION)
print('There are %d bytes per sample.' % WIDTH)

# Set parameters of delay system
Gdp = 1.0           # direct-path gain
Gff = 0.8           # feed-forward gain
delay_sec = 0.5    # 50 milliseconds
# delay_sec = 0.02
delay_samples = int( RATE * delay_sec )

print('The delay of {0:.3f} seconds is {1:d} samples.'.format(delay_sec, delay_samples))

# Create a buffer to store past values. Initialize to zero.
BUFFER_LEN = delay_samples   # set the length of buffer
buffer = [ 0 for i in range(BUFFER_LEN) ]    

# Open an output audio stream
p = pyaudio.PyAudio()
stream = p.open(format      = pyaudio.paInt16,
                channels    = CHANNELS,
                rate        = RATE,
                input       = True,
                output      = True )


# Get first frame (sample)
#input_string = wf.readframes(1)

k = 0       # buffer index (circular index)

print("* Start *")

for n in range(0, DURATION):

    # Get one frame from audio input (microphone)
    # input_string = stream.read(1)
    # If you get run-time time input overflow errors, try:
    # number of frames or samples to read. 1 for mono, 2 for stereo
    input_string = stream.read(1, exception_on_overflow = False) 
    # Convert binary string to tuple of numbers
    input_tuple = struct.unpack('h', input_string)

    # Convert one-element tuple to number
    input_value = input_tuple[0]


# while len(input_string) > 0:

    # Convert string to number
    # input_value = struct.unpack('h', input_string)[0]

    # Compute output value
    output_value = Gdp * input_value + Gff * buffer[k]

    # Update buffer
    buffer[k] = input_value

    # Increment buffer index
    k = k + 1
    if k >= BUFFER_LEN:
        # The index has reached the end of the buffer. Circle the index back to the front.
        k = 0

    # Convert output value to binary string
    output_string = struct.pack('h', int(clip16(output_value)))

    # Write output value to audio stream
    stream.write(output_string)
    wf.writeframes(output_string)
    # Get next frame (sample)
    #input_string = wf.readframes(1)     

print("* Finished *")

stream.stop_stream()
stream.close()
p.terminate()
