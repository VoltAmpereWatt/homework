# filter_16.py
# 
# Implement the second-order recursive difference equation
# y(n) = x(n) - a1 y(n-1) - a2 y(n-2)
# 
# 16 bit/sample

from math import cos, pi 
import pyaudio                              
import struct
import wave

# Fs : Sampling frequency (samples/second)
Fs = 8000
# Also try other values of 'Fs'. What happens? Why?
# Fs = 16000
# Fs = 32000
# Fs = 5000

T = 1       # T : Duration of audio to play (seconds)
N = T*Fs    # N : Number of samples to play

# Difference equation coefficients
a1 = -1.9
a2 = 0.998

# Initialization
y1 = 0.0
y2 = 0.0
gain = 1000000
# Also try other values of 'gain'. What is the effect?
# gain = 1000.0

# Create an audio object and open an audio stream for output
p = pyaudio.PyAudio()
#stream holds the properties of the pyaudio object.
stream = p.open(format = pyaudio.paInt16, #16 bits per sample
                channels = 1, #single channel output
                rate = Fs, #number of frames per second
                input = False, #false because not using or reeading from input device
                output = True)

# paInt16 is 16 bits/sample
wf = wave.open('gain_1m.wav','w')
wf.setnchannels(1)
wf.setsampwidth(2)
wf.setframerate(Fs)
# Run difference equation
for n in range(0, N):

    # Use impulse as input signal
    #delta function created. 
    if n == 0:
        x0 = 1.0
    else:
        x0 = 0.0

    # Difference equation
    y0 = x0 - a1 * y1 - a2 * y2

    # Delays
    #updating the values of the previous two elements
    #essentially order of filter
    y2 = y1
    y1 = y0

    # Output
    #multiplying by gain to get input in 2^16 range
    output_value = gain * y0
    if output_value >= 2**15-1:
        output_value = 2**15-1
    elif output_value <= -2**15:
        output_value = -2**15
    output_string = struct.pack('h', int(output_value))   # 'h' for 16 bits
    stream.write(output_string)
    wf.writeframes(output_string)
    
print('WAV file generated\n',"* Finished *")
wf.close()
stream.stop_stream()
stream.close()
p.terminate()