import pyaudio
import wave
import struct
import math

def clip16( x ):    
    # Clipping for 16 bits
    if x > 32767:
        x = 32767
    elif x < -32768:
        x = -32768
    else:
        x = x        
    return (x)

gain = 10

dir = 'C:/Users/rrr39/Google Drive/Academics/DSP Lab 18/assignments/3/'
wavefileMono = 'sin01_mono.wav'
wavefileStereo = 'sin01_stereo.wav'

print('Play the wave files %s and %s.' %(wavefileMono,wavefileStereo))

wfMono = wave.open(wavefileMono, 'rb' )
wfStereo = wave.open(wavefileStereo, 'rb')

(numChannelsMono, numChannelsStereo) = (wfMono.getnchannels(), wfStereo.getnchannels()) # Number of channels
(rateMono, rateStereo) = (wfMono.getframerate(), wfStereo.getframerate()) # Sampling rate (frames/second)
(signalLengthMono, signalLengthStereo) = (wfMono.getnframes(), wfStereo.getnframes()) # Signal length
(widthMono, widthStereo) = (wfMono.getsampwidth(), wfStereo.getsampwidth()) # Number of bytes per sample

print('Mono Channel audio file information')
print('The file has %d channel(s).' % numChannelsMono)
print('The frame rate is %d frames/second.' % rateMono)
print('The file has %d frames.' % signalLengthMono)
print('There are %d bytes per sample.' % widthMono)

print('Mono Channel audio file information')
print('The file has %d channel(s).' % numChannelsStereo)
print('The frame rate is %d frames/second.' % rateStereo)
print('The file has %d frames.' % signalLengthStereo)
print('There are %d bytes per sample.' % widthStereo)

p = pyaudio.PyAudio()

#Reading Mono Channel File
# Open audio stream
stream = p.open(
    format      = pyaudio.paInt16,
    channels    = numChannelsMono,
    rate        = rateMono,
    input       = False,
    output      = True)

input_string = wfMono.readframes(1)

while len(input_string) > 0:

    # Convert string to number
    input_tuple = struct.unpack('h', input_string)  # One-element tuple (unpack produces a tuple)
    input_value = input_tuple[0]                    # Number #floating point value

    # Compute output value
    output_value = int(clip16(gain * input_value))  # Integer in allowed range
    
    # Convert output value to binary string
    output_string = struct.pack('h', output_value)  
    
    # Write binary string to audio stream
    stream.write(output_string)                     

    # Get next frame
    input_string = wfMono.readframes(1)

print('* Finished playing mono-channel file*')

stream = p.open(
    format      = pyaudio.paInt16,
    channels    = numChannelsStereo,
    rate        = rateStereo,
    input       = False,
    output      = True )

# Read first frame
input_string = wfStereo.readframes(1)          

while len(input_string) > 0:

    # Convert string to numbers
    input_tuple = struct.unpack('hh', input_string)  # produces a two-element tuple
    # Compute output values
    output_value0 = int(clip16(gain * input_tuple[0]))
    output_value1 = int(clip16(gain * input_tuple[1]))

    # Convert output value to binary string
    output_string = struct.pack('hh', output_value0, output_value1)

    # Write output value to audio stream
    stream.write(output_string)

    # Get next frame
    input_string = wfStereo.readframes(1)

print('* Finished playing stereo file')

stream.stop_stream()
stream.close()
p.terminate()
