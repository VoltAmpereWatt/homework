
# coding: utf-8

# # Question 5

# The desired impulse response is $h(n)=r^n\cos(\omega_1n)u(n)$. The Z-transform of this expression is: $$H(z)=\frac{1-r\cos(\omega_1)z^{-1}}{1-2r\cos(\omega_1)z^{-1}+r^2z^{-2}}$$

# The required transfer function is $$H(z)=\frac{b_0+b_1z^{-1}+b_2z^{-2}}{1+a_1z^{-1}+a_2z^{-2}}$$

# Comparing coefficeints, we get $b_0=1,b_1=-r\cos(\omega_1),b_2=0\\a_0=1,a_1=-2rcos(\omega_1),a_2=r^2$

# We can see that $b_1$ is half of $a_1$, and `a1 = -1.9`, so `b1 = -0.95`, and `a0 = 1` and `b0 = 1`.

# In[5]:


# filter_16.py
# 
# Implement the second-order recursive difference equation
# y(n) = x(n) - a1 y(n-1) - a2 y(n-2)
# 
# 16 bit/sample

from math import cos, pi 
import pyaudio                              
import struct
import wave

# Fs : Sampling frequency (samples/second)
Fs = 8000
# Also try other values of 'Fs'. What happens? Why?
# Fs = 16000
# Fs = 32000
# Fs = 5000

T = 1       # T : Duration of audio to play (seconds)
N = T*Fs    # N : Number of samples to play

# Difference equation coefficients
(b1,b2,a1,a2)=(-0.95,0,-1.9,0.998)

# Initialization
y1 = 0.0
y2 = 0.0
gain = 10000
# Also try other values of 'gain'. What is the effect?
# gain = 1000.0

# Create an audio object and open an audio stream for output
p = pyaudio.PyAudio()
#stream holds the properties of the pyaudio object.
stream = p.open(format = pyaudio.paInt16, #16 bits per sample
                channels = 1, #single channel output
                rate = Fs, #number of frames per second
                input = False, #false because not using or reeading from input device
                output = True)

# paInt16 is 16 bits/sample
wf = wave.open('q5.wav','w')
wf.setnchannels(1)
wf.setsampwidth(2)
wf.setframerate(Fs)
# Run difference equation
for n in range(0, N):

    # Use impulse as input signal
    #delta function created. 
    if n == 0:
        (x0,x1,x2) = (1.0,0.0,0.0)
    elif n == 1:
        (x0,x1,x2) = (0.0,1.0,0.0)
    elif n == 2:
        (x0,x1,x2) = (0.0,0.0,1.0)
        
    else:
        (x0,x1,x2) = (0.0,0.0,0.0)

    # Difference equation
    y0 = x0 + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2

    # Delays
    #updating the values of the previous two elements
    #essentially order of filter
    
    (x2,x1,y2,y1)=(x1,x0,y1,y0)
    # Output
    #multiplying by gain to get input in 2^16 range
    output_value = gain * y0
    if output_value >= 2**15-1:
        output_value = 2**15-1
    elif output_value <= -2**15:
        output_value = -2**15
    output_string = struct.pack('h', int(output_value))   # 'h' for 16 bits
    stream.write(output_string)
    wf.writeframes(output_string)
    
print('WAV file generated\n',"* Finished *")
wf.close()
stream.stop_stream()
stream.close()
p.terminate()

