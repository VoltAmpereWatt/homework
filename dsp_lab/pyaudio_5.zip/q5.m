clc;
clear all; close all;

%% Filter coefficients 
%Obtained from Python code 
b0 = 1; b1 = -0.95; b2 = 0;
a0 = 1; a1 = -1.9; a2 = 0.998;

b = [b0 b1 b2]; a = [a0 a1 a2];

%% Input generation and filtering
N = 5000; 
ip = [1; zeros(N-1,1)];

impresp = filter(b, a, ip);

%% Plotting of impulse response
plot(0:N-1,impresp,'k');
title(sprintf('Impulse Response (Max value = %.3f )', max(impresp)));
grid on;