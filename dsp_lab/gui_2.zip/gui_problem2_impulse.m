function filter_gui_example_ver1
clc; clear all; close all;
N = 500;
n = 1:N;
x = [1;zeros(N-1,1)]; % Impulse input signal
y=filter(1,[1 -2*1.1*cos(-0.9) -1.1],x);
f=figure;
clf;
line_handle = plot(0:N-1, x);
title('Noisy data', 'fontsize', 12 )% 
% freq_y=fft(y);
% freq_y=abs(freq_y);
% freq_handle=plot(freq_y);

xlabel('Time')
box off
xlim([-10, N]);
% b=figure;

drawnow;
    slider_handle1 = uicontrol('Style', 'slider', ...
    'Min', -2*pi, 'Max', 2*pi,...
    'Value', 0.2, ...
    'SliderStep', [0.02 0.05], ...
    'Position', [5 5 200 20], ...  % [left, bottom, width, height]
    'Callback',  {@fun1, line_handle, x}    );
% drawnow;
%     slider_handle2 = uicontrol('Style', 'slider', ...
%     'Min', -2*pi, 'Max', 2*pi,...
%     'Value', 0.2, ...
%     'SliderStep', [0.02 0.05], ...
%     'Position', [5 5 200 20], ...  % [left, bottom, width, height]
%     'Callback',  {@fun2, freq_handle, x}    );
end


function fun1(hObject, eventdata, line_handle, x)

fc = get(hObject, 'Value');  % fc : cut-off frequency
r = 1.1;
b=1;
a0 = 1; a1 = -2*r*cos(fc); a2 = r^2;
y = filter(b, [a0 a1 a2], x);
% yf = fft(y);
% yf = abs(yf);
set(line_handle, 'ydata', y);        % Update data in figure
% set(freq_handle, 'ydata',yf);
title(sprintf('Output of LPF. Cut-off frequency = %.3f', fc),'fontsize',12)
end
% 
% function fun2(hObject, eventdata, freq_handle, x)
% 
% fc = get(hObject, 'Value');  % fc : cut-off frequency
% r = 1.1;
% b=1;
% a0 = 1; a1 = -2*r*cos(fc); a2 = r^2;
% y = filter(b, [a0 a1 a2], x);
% yf = fft(y);
% yf = abs(yf);
% % set(line_handle, 'ydata', y);        % Update data in figure
% set(freq_handle, 'ydata',yf);
% title(sprintf('Output of LPF. Cut-off frequency = %.3f', fc),'fontsize',12)
% end
